## Follow belows steps to install this project
* Download the project or clone it ```git clone git@github.com:MRRaihan/Excelanto```
* __Run:__ ```cp .env.example .env``` then configure your database
* __Run:__ ```composer install```
* __Run:__ ```php artisan key:generate```
* __Run:__ ```php artisan migrate:fresh --seed```

## Now you are ready to go  :).

## Credintials to login
* __Password:__ Password is ```12345``` for all portal
* __Super admin:__ ```sa@gmail.com```
* __Bangladesh admin:__ ```ba@gmail.com```
* __Recruiting agency:__ ```rea@gmail.com```
* __Welfare sevice centre:__ ```wsc@gmail.com```
* __Master One stop service:__ ```moss@gmail.com```
* __Bangladesh Embassy:__ ```be@gmail.com```
* __Uae Admin:__ ```uaeadmin@gmail.com```
* __Child One Stop Service:__ ```coss@gmail.com```
* __Medical Agency:__ ```ma@gmail.com```
* __Training Agency:__ ```ta@gmail.com```
* __Travel Agency:__ ```travel@gmail.com```
* __Biometric Agency:__ ```bio@gmail.com```
* __Uae Embassy:__ ```ue@gmail.com```
* __Employer Company:__ ```ec@gmail.com```
* __Candidate:__ ```candidate@gmail.com```
