<footer class="footer">
    2016 © Xadmino.
</footer>
